## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(consensus)
#library(stringr)

## ------------------------------------------------------------------------
# the_ranking <- "a > b ~ c > d > e"
# the_ranking <- parse_ranking(the_ranking)
# class(the_ranking)
# print.default(the_ranking)

