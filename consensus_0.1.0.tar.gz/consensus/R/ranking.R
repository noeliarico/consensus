

print.ranking <- function(x) {
  cat("This is ranking\n")
}
