library(testthat)
library(consensus)

test_check("consensus")
